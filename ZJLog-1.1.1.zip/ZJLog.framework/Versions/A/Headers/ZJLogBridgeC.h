//
//  ZJLogBridgeC.h
//  ZJLog
//
//  Created by lzj<lizhijian_21@163.com> on 2019/1/8.
//  Copyright © 2019 ZJ. All rights reserved.
//

#ifndef ZJLogBridgeC_h
#define ZJLogBridgeC_h

extern void CPrintfSendCallback(char *log);

#endif /* ZJLogBridgeC_h */
