//
//  JMBaseViewController.h
//  JMSmartUtils
//
//  Created by YaoHua Tan on 2020/1/15.
//  Copyright © 2020 Jimi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JMBaseViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
