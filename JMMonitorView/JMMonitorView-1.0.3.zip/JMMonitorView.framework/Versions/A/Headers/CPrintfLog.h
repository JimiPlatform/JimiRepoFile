//
//  CPrintfLog.h
//  JMMonitorView
//
//  Created by lzj<lizhijian_21@163.com> on 2018/7/16.
//  Copyright © 2018年 Jimi. All rights reserved.
//

#ifndef CPrintfLog_h
#define CPrintfLog_h

#import <ZJLog/ZJPrintfLog.h>

#endif /* CPrintfLog_h */
